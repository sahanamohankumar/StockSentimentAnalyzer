//
//  FinalTests.swift
//  FinalTests
//
//  Created by Sahana Mohankumar on 5/12/25.
//

import Testing
@testable import Final

struct FinalTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
